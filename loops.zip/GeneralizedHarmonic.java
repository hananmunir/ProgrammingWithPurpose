

public class GeneralizedHarmonic {
	public static void main(String[] args) 
	{
		double sum = 0;
		for ( int i= 1 ; i <= Integer.parseInt(args[0]) ; i++ )
		{
			sum = sum + ( 1/Math.pow( i, Integer.parseInt(args[1])));
		}
		System.out.println(sum);
	}
}
