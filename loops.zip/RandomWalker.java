

public class RandomWalker {
	public static void main(String[] args)
	{
		
		int r = Integer.parseInt(args[0]);
		int x = 0;
		int y = 0;
		double rand;
		int steps = 0;
		System.out.printf("(%d,%d)\n",x,y);
		while ( ( Math.abs(x) + Math.abs(y) != r ))
		{
				rand = Math.random();
				if ( rand <= 0.25 ) 
					x++;
				else 
					if ( rand <= 0.5 )
						y++;
				else 
					if ( rand <= 0.75 )
						x--;
				else 
					y--;
				System.out.printf("(%d,%d)\n",x,y);
				steps++;
		} 
		System.out.println("steps = "+steps);
	}

}
