

public class RandomWalkers {
	public static void main(String[] args)
	{
		int r = Integer.parseInt(args[0]);
		int x ;
		int y ;
		int steps;
		int tSteps = 0;
		int iterates = Integer.parseInt(args[1]);
		double avgSteps , rand;
	
		for (int i = 0 ; i< iterates ; i++ )
		{
			steps = 0;
			x = 0;
			y = 0;
			while (( Math.abs(x) + Math.abs(y) != r ))
			{
				rand = Math.random();
				if ( rand <= 0.25 ) 
					x++;
				else 
					if ( rand <= 0.5 )
						y++;
				else 
					if ( rand <= 0.75 )
						x--;
				else 
					y--;
				steps++;
			}
			tSteps = steps + tSteps ;
		}
		avgSteps = (double) tSteps / iterates ;
		System.out.println("average number of steps = "+ avgSteps);
	}

}
