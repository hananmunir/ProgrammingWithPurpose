//Author: Hanan Munir FA19_BSE_011
import java.util.Scanner;
public class Simpletron	
{	
	//delares and initializes counters
	private static int argcounter;
	private static int op=0;
	private static int reg=0;
	private static int accum=0;
	
	//controls the operations 
	public static void operations(int CMD,int[] commands)
	{
		//gets the first 2 digits from the command
		op=CMD/100;
		//gets the last 2 digits from the command
		reg=CMD%100;  
		System.out.printf("%nREGISTER%nOperation code:%d%nRegister number:%d%nAccumlator:%d%n",op,reg,accum);
		
		print(commands);//calls the method that prints the accumlator 
			
		//performs on the basis of command
		switch(op)
		{	
			//loads a number in accumlator
			case 10:
				Scanner input=new Scanner(System.in);
				System.out.printf("Enter a Number:");
				commands[reg]=input.nextInt();
				break;
				
			// Write a word from a specific location in memory to the screen
			case 11:
				System.out.printf("%nValue in memory:%d%n",commands[reg]);
				break;
				
			//Load a word from a specific location in memory into the accumulator 	
			case 20:
				accum=commands[reg];
				break;
				
			//Store a word from the accumulator into a specific location in memory	
			case 21: 
				commands[reg]=accum;
				break;
				
			//Add a word from a specific location in memory to the word in the accumulator	
			case 30:
				accum=accum+commands[reg];
				break;
				
			//Subtract awordfromaspecific locationinmemory fromthe word in the accumulator
			case 31:
				accum=accum-commands[reg];
				break;
				
			//Divide a word from a specific location in memory into the word in the accumulator	
			case 32:
				accum=commands[reg]/accum;
				break;
				
			//Multiply a word from a specific location in memory by the word in the accumulator
			case 33: 
				accum=accum*commands[reg];
				break;
				
			// Branch to a specific location in memory
			case 40:
				operations(commands[reg],commands);
				break;
				
			//Branch to a specific location in memory if the accumulator is negative
			case 41:
				if (accum<0)
					operations(commands[reg],commands);
				
				break;
				
			//Branch to a specific location in memory if the accumulator is zero	
			case 42:
				if (accum==0)
					operations(commands[reg],commands);
				
				break;
				
			//Halt. The program has completed its task	
			case 43:
				System.exit(0);
			default:
				System.out.println("The Command is  not Recognisable%n");
		}
	}
	
	//prints accumalator 
	public static void print(int[] commands)
	{
		
		int dspcounter=0;
			for(dspcounter=0;dspcounter<commands.length;dspcounter++)
			{	
				if (commands[dspcounter]!=0)
					System.out.printf("%4d ",commands[dspcounter]);
				
				else

					System.out.printf("0000 ");
				
					//prints new line after every 10 enteries
					if((dspcounter+1)%10==0)
						System.out.printf("%n");
			}
		System.out.printf("%n%n");
		}
		
		
	public static void main(String[] args)
	{
		
		int[] commands=new int[100];
		for(argcounter=0;argcounter<args.length;argcounter++)
		{
			commands[argcounter]=Integer.parseInt(args[argcounter]);
		}
		
		for(argcounter=0;argcounter<args.length;argcounter++)
		{	
			//calls method operations
			operations(commands[argcounter],commands);
				
		}
	}
	
}