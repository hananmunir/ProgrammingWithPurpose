

public class ActivationFunction {
	public static double heaviside(double x)
	{
		if ( x<0 )
			return 0.0;
		else if ( x == 0)
			return 0.5;
		else 
			return 1;
		
	}
	
	public static double sigmoid(double x)
	{
		return 1/ (1 + 1/Math.pow(Math.E,x));
	}
	
	public static double tanh(double x)
	{
		return (Math.pow(Math.E, x) - 1/Math.pow(Math.E, x)) / (Math.pow(Math.E, x) + 1/Math.pow(Math.E, x));
	}
	
	public static double softsign (double x)
	{
		return  x/ (1 + Math.abs(x));
	}
	
	public static double sqnl(double x)
	{
		if ( x<=-2 )
			return -1;
		else
			if( x<0 )
				return x + (x*x/4);
			else
				if ( x<2 )
					return x - (x*x/4);
				else
					return 1;
					
				
	}
	public static void main(String[] args) 
	{
		double x=Double.parseDouble(args[0]);
		System.out.printf("Heaviside(%.1f) = %f\n",x,heaviside(x));
		System.out.printf("sigmoid(%.1f) = %f\n",x,sigmoid(x));
		System.out.printf("tanh(%.1f) = %f\n",x,tanh(x));
		System.out.printf("softsign(%.1f) = %f\n",x,softsign(x));
		System.out.printf("sqnl(%.1f) = %f",x,sqnl(x));
		
	} 
}
