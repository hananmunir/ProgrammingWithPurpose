

public class Divisors {
	public static void main(String [] args)
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		System.out.printf("gcd(%d, %d) = %d\n", a, b, gcd(a,b));
		System.out.printf("lcm(%d, %d) = %d\n", a, b, lcm(a,b));
		System.out.printf("areRelativelyPrime(%d, %d) = %b\n", a, b, areRelativelyPrime(a,b));
		System.out.printf("totient(%d) = %d\n", a, totient(a));
		System.out.printf("totient(%d) = %d", b, totient(b));
	}

	public static int gcd(int a,int b)
	{
		a = Math.abs(a);
		b = Math.abs(b);
		while(b != 0)
		{
			
			int temp = a;
			a = b;
			b = temp%b;
			a = Math.abs(a);
			b = Math.abs(b);
		}
		
		return a;
	}
	
	public static int lcm(int a,int b)
	{
		a = Math.abs(a);
		b = Math.abs(b);
		
		return ( a/gcd(a,b) ) *b;
	}
	
	public static boolean areRelativelyPrime(int a,int b)
	{
		if (gcd(a,b) == 1)
		{
			return true;
		}
		else 
			return false;
	}
	
	public static int totient(int n)
	{
		if (n <= 0)
			return 0;
		else
		{
			int counter = 0,b = 1;
			
			while(b <= n) 
			{
				if ( areRelativelyPrime(n,b)==true)
					counter++;
				
				b++;
			}
			return counter;
		}		
	}
	
}
