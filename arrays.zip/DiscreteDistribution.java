

public class DiscreteDistribution {
	public static void main(String [] args)
	{
		int rIndice = Integer.parseInt(args[0]);
		int [] a = new int[args.length-1];
		int [] sum= new int[a.length+1];
		int r;
		
		for ( int i = 0; i < args.length-1 ; i++ )
		{
			a[i] = Integer.parseInt(args[i+1]) ;
		}
		
		for ( int i = 1; i <= a.length ; i++ )
		{
			sum[i] = sum[i-1] + a[i-1];
		}
		
		for ( int j = 0; j < rIndice ; j++ )
		{
			r = (int) (Math.random()*(sum[sum.length-1]-1));
			for ( int i = 1 ; i < sum.length ; i++)
			{
				if (r >= sum[i-1] &&  r < sum[i]) 
				{
					System.out.printf("%d ", i);
				}
			
			}
		}
	}

}
