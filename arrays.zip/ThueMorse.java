


public class ThueMorse {
	public static void main(String [] args)
	{
		int n = Integer.parseInt(args[0]);
		int [] array = new int [n];
		int [] cope= new int [8];
		cope [0] = 0;
		cope[1] = 1;
		cope[2]=1;
		cope[3]=0;
		cope[4]=1;
		cope[5]=0;
		cope[6]=0;
		cope[7]=1;
		for(int i =0; i < array.length && i<cope.length; i++)
		{
			array[i]=cope[i];
		}
		for ( int i = 8 ; i < n ; i*=2)
		{
		  for ( int j = 0 , k = i ; k < n ; j++ , k++)
		  {

			  if ( array[j] == 0 )
				  array[k] = 1;
			  else
				  array[k] = 0;
			  if (k>n)
				  break;
		  }
		}
		
		for ( int i = 0 ; i < n ; i++)
		{
			for ( int j = 0; j < n ; j++)
			{
				if (array [i] == array [j])
					System.out.print("+  ");
				else 
					System.out.print("-  ");
					
			}
			System.out.println();
		}
	}
}
