
public class Minesweeper {
	public static void main(String[] args)
	{
		int m = Integer.parseInt(args[0]);
		int n = Integer.parseInt(args[1]);
		int k = Integer.parseInt(args[2]);
		String[][] populate = new String [m][n];
		for ( int i = 0; i < k ;i++)
		{
			int ran1 =(int) (Math.random()*m);
			int ran2 = (int) (Math.random()*n);
			
			if ( populate[ran1][ran2] == null )
			{
				populate[ran1][ran2] = "*";
				
			}
			else 
			{
				i--;}
			
		}
		for( int i = 0; i < m ; i++)
		{
			for ( int j = 0; j < n; j++)
			{
				if ( populate [i][j] == null)
					populate[i][j] = "0";
			}
		}
		String set= "*";
		for ( int i = 0; i < m ; i++)
		{
			for ( int j = 0; j < n ; j ++)
			{
				if (populate[i][j]== "0")
				{
					int dis = 0;
					if (i-1>=0 && (populate [i-1][j].equals(set)))
							{dis++;
							}
					if (j-1>=0 && (populate [i][j-1].equals(set)))
							{dis++;
						}
					if (i-1 >= 0 && j-1 >= 0 && (populate [i-1][j-1].equals(set)))
							{dis++;
							}
					if (i-1>= 0 && j+1 < n && (populate [i-1][j+1].equals(set)))
							{dis++;
							}
					if ( i+1 < m && j-1 >= 0 && (populate [i+1][j-1].equals(set)))
							{dis++;	
							}
					if ( i+1 <m && populate [i+1][j].equals(set))
						{dis++;
						}
					
					if (j+1 < n && (populate [i][j+1].equals(set)))
						{dis++;
						}
					
					if ( i+1 < m && j+1 < n && (populate [i+1][j+1].equals(set)))
						{dis++;
						}
					
					populate [i][j]=Integer.toString(dis);
				}
			}	
		}
		for( int i = 0; i < m ; i++)
		{
			for ( int j = 0; j < n; j++)
			{
					System.out.printf("%3s", populate[i][j]);
			}
			System.out.println();
		}
	}

}
