

public class Birthday {
	public static void main(String [] args)
	{
		int n = Integer.parseInt(args[0]);
		int trials = Integer.parseInt(args[1]);
		
		
		int [] sum= new int [n];
		int [] count = new int [n];
		double percentage=0;
		int breakPoint=0;
		int rand=0;
		sum[0]=0;
		for ( int i = 1 ; i < trials ; i++)
		{
			boolean[] birthday = new boolean[n];
			
			for (int j = 1; birthday[rand] == false; j++)
			{
				birthday[rand] = true;
				rand = (int) (Math.random()*(n-1));
				breakPoint=j;
				
			}	
			count[breakPoint]++;
		}
		for ( int k = 0;k<n  ; k++)
		{
			sum[k+1] = sum[k]+count[k+1];
			percentage=(double)sum[k]/trials;
			System.out.printf("%2d\t%d\t%.8f\n",k,count[k],percentage);
			if (percentage >= 0.50)
				break;
		}
	}
}

