public class GreatCircle
{
	public static void main(String [] args)
	{
		double x1= Math.toRadians(Double.parseDouble(args[0]));
		double y1= Math.toRadians(Double.parseDouble(args[1]));
		double x2= Math.toRadians(Double.parseDouble(args[2]));
		double y2= Math.toRadians(Double.parseDouble(args[3]));
		double r= 6371.0;
		double b= (y2-y1)/2;
		double a= (x2-x1)/2;
		double sin1= Math.sin(a)*Math.sin(a);
		double sin2= Math.cos(x1)*Math.cos(x2)*Math.sin(b)*Math.sin(b);
		double underRoot= Math.sqrt(sin1+sin2);
		
		double distance=2*r*Math.asin(underRoot);
		System.out.println(distance+ " Kilometers");
		
	}
}