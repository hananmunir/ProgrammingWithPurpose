

public class RightTriangle {
	public static void main(String[] args )
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c=Integer.parseInt(args[2]);
		boolean number= a>-1 && b>-1 && c>-1;
		boolean p1= a*a+b*b == c*c  ;
		boolean p2=a*a+c*c==b*b ;
		boolean p3=b*b+c*c==a*a;
		boolean right= p1|| p2 || p3;
		boolean answer= number && right;
		System.out.println(answer);
		
	}
}
