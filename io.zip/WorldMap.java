public class WorldMap {

    public static void main(String[] args){
        int w = StdIn.readInt();
        int h = StdIn.readInt();

        StdDraw.setCanvasSize(w, h);
        StdDraw.setXscale(0.0, (double) w);
        StdDraw.setYscale(0.0, (double) h);

        while(!StdIn.isEmpty()){

            String region = StdIn.readString();

            int n = StdIn.readInt();

            double[] a = new double[n];
            double[] b = new double[n];

            for(int i=0; i<n; i++){
                a[i] = StdIn.readDouble();
                b[i] = StdIn.readDouble();
            }
            StdDraw.polygon(a, b);
        }

    }
}