public class Checkerboard {

    public static void main(String[] args){
                int a = Integer.parseInt(args[0]);
                StdDraw.setXscale(0, a);
                StdDraw.setYscale(0, a);

                for (int i = 0; i < a; i++) {
                    for (int j = 0; j < a; j++) {
                        if ((i + j) % 2 != 0) StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
                        else                  StdDraw.setPenColor(StdDraw.BLUE);
                        StdDraw.filledSquare(i + 0.5, j + 0.5, 0.5);
                    }
                }
    }
}